<?php

/**
 * @file plugins/importexport/marcalycImporter/index.php
 *
 * Copyright (c) 2019
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @ingroup plugins_importexport_marcalycImporter
 * @brief Importa un numero a OJS creado desde Marcalyc.
 *
 */

require_once('MarcalycImportPlugin.inc.php');

return new MarcalycImportPlugin();


